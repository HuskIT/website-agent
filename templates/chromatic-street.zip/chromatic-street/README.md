
  # ChromaticStreet

  This is a code bundle for ChromaticStreet. The original project is available at https://www.figma.com/design/feYefQMmAtWMX3tOEU9lA3/ChromaticStreet.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  