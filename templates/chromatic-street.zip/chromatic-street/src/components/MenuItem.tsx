import React from "react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export function MenuItem({ item, image }) {
  return (
    <div className="border-4 border-black shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all bg-white flex flex-col">
      <div className="h-48 border-b-4 border-black overflow-hidden relative">
        <ImageWithFallback 
          src={image} 
          alt={item.name} 
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110" 
        />
        <div className="absolute top-0 right-0 bg-black text-white px-3 py-1 font-black text-lg border-l-4 border-b-4 border-white">
          {item.price}
        </div>
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-2xl font-black uppercase mb-2 leading-none">{item.name}</h3>
        <p className="text-gray-600 font-bold text-sm mb-4 flex-grow">{item.desc}</p>
      </div>
    </div>
  );
}
