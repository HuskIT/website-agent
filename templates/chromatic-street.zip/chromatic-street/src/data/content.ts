const siteText = {
  seo: {
    title: "Culinary Haven | SouthEast Asian Flavors",
    metaDescription: "Experience the essence of SouthEast Asian cuisine. Authentic flavors, delivered or dined in.",
  },
  branding: {
    name: "The Chromatic Street"
  },
  common: {
    hours: "Hours",
    join: "Join",
    location: "Location"
  },
  navigation: [
    { label: "Home", path: "/" },
    { label: "Menu", path: "/menu" },
    { label: "Our Story", path: "/about" },
    { label: "Contact", path: "/#contact" }
  ],
  hero: {
    headline: "Experience the Finest SouthEast Asian Flavors",
    cta: { label: "View Menu", link: "/menu" },
    imageAlt: "Vibrant Asian street food feast"
  },
  featureBlock: {
    heading: "Discover the Essence",
    body: "Indulge in the diverse and vibrant flavors. From the bustling night markets of Bangkok to the serene rice paddies of Vietnam, our ingredients tell a story of tradition, passion, and uncompromised quality.",
    imageAlt: "Chef pouring broth into bowl" 
  },
  storyBlock: {
    heading: "Embark on a Culinary Adventure",
    body: "Each bite tells a story of local ingredients. Immerse yourself in the vibrant tapestry of tastes that define our heritage. Every dish is a chapter in our story, written with spice, fire, and soul.",
    imagesAlts: [
      "Spoons of spices",
      "Asian street market",
      "Noodle soup"
    ],
    cta: { label: "Discover More", link: "/about" }
  },
  storyPage: {
    heading: "Our Story",
    subhead: "Born from the heat of the street and the soul of the kitchen.",
    heroImageAlt: "Our Chef",
    content: {
      heading: "Tradition Meets Chaos",
      body: [
        "The Chromatic Street isn't just a restaurant; it's a collision of cultures. We started in a tiny stall in the night markets, serving up family recipes passed down through generations.",
        "But we didn't want to just replicate the past. We wanted to paint it with new colors. Our food is loud, spicy, and unapologetic. It's the taste of the street, amplified.",
        "We believe in the power of a shared meal. The clatter of chopsticks, the steam rising from a hot bowl of pho, the burst of flavor from a perfectly spiced curry. This is our language."
      ]
    },
    values: [
      { title: "Fresh", desc: "Ingredients sourced daily from local markets." },
      { title: "Bold", desc: "Flavors that don't apologize. Spice that kicks." },
      { title: "Authentic", desc: "Rooted in tradition, served with a twist." }
    ]
  },
  fullMenu: {
    heading: "The Menu",
    subhead: "Street food classics reimagined. Bold flavors, fresh ingredients, no compromises.",
    starters: {
      title: "Small Plates",
      items: [
        { id: 101, name: "Crispy Tofu", price: "$8", desc: "Golden fried tofu with sweet chili peanut sauce." },
        { id: 102, name: "Spring Rolls", price: "$9", desc: "Glass noodles, cabbage, and carrots in a crispy wrapper." },
        { id: 103, name: "Satay Skewers", price: "$11", desc: "Grilled marinated chicken with peanut dipping sauce." },
      ],
    },
    mains: {
      title: "Bowls & Curries",
      items: [
        { id: 201, name: "Chicken Massaman", price: "$18", desc: "Slow-cooked chicken in rich coconut curry with potatoes." },
        { id: 202, name: "Red Curry", price: "$17", desc: "Spicy red curry with bamboo shoots, basil, and choice of protein." },
        { id: 203, name: "Pad Thai Street Style", price: "$16", desc: "Rice noodles, egg, peanuts, bean sprouts, and tamarind sauce." },
        { id: 204, name: "Drunken Noodles", price: "$16", desc: "Wide rice noodles stir-fried with chili, basil, and vegetables." },
      ]
    },
    drinks: {
      title: "Refreshments",
      items: [
        { id: 301, name: "Thai Iced Tea", price: "$5", desc: "Authentic brewed tea with condensed milk." },
        { id: 302, name: "Coconut Water", price: "$6", desc: "Fresh young coconut." },
      ]
    }
  },
  menuPreview: {
    heading: "Savor a fusion of exquisite flavors",
    items: [
      {
        name: "Crispy Tofu Pad Thai",
        desc: "Classic stir fry with sweet chili peanut sauce."
      },
      {
        name: "Chicken Massaman Curry",
        desc: "Rich coconut curry with potatoes and slow-cooked chicken."
      },
      {
        name: "Sai Mai Red Curry",
        desc: "Spicy and aromatic red curry with bamboo shoots and basil."
      }
    ],
    cta: { label: "View Menu", link: "/menu" }
  },
  footer: {
    newsletterHeading: "Stay Up to Date",
    hours: "Mon-Sun: 11am - 10pm",
    address: "500 Terry Francine St, San Francisco, CA",
    signup: "Sign up for drops, secret menu items, and spicy news."
  }
};

const siteAssets = {
  staticAssets: {
    colors: {
      primary: "#FF5722", // Vibrant Orange
      secondary: "#2962FF", // Electric Blue
      highlight: "#FFEB3B", // Bright Yellow
      textDark: "#1A1A1A",
      textLight: "#FFFFFF",
      storyPageValues: ["#FFEB3B", "#FF5722", "#2962FF"]
    },
    images: {
      featureBlock: "https://images.unsplash.com/photo-1752654976426-f0de0cbf8bb5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxDaGVmJTIwcG91cmluZyUyMGJyb3RoJTIwbm9vZGxlJTIwYm93bCUyMHN0ZWFtfGVufDF8fHx8MTc2NDUwMDEzOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      fullMenu: {
        starters: [
          "https://images.unsplash.com/photo-1762305194201-077e7e23ccf2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxDcmlzcHklMjBUb2Z1JTIwYXNpYW4lMjBkaXNofGVufDF8fHx8MTc2NDUwMDEzOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
          "https://images.unsplash.com/photo-1608131922243-00b9ae767eec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTcGljZXMlMjBpbiUyMHNwb29ucyUyMGNvbG9yZnVsfGVufDF8fHx8MTc2NDUwMDEzOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
          "https://images.unsplash.com/photo-1672172505672-babacdc28071?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBc2lhbiUyMHN0cmVldCUyMGZvb2QlMjBtYXJrZXQlMjBuaWdodHxlbnwxfHx8fDE3NjQ1MDAxMzl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
        ],
        mains: [
          "https://images.unsplash.com/photo-1708782340377-882559d544fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxDaGlja2VuJTIwTWFzc2FtYW4lMjBjdXJyeSUyMGJvd2x8ZW58MXx8fHwxNzY0NTAwMTM5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
          "https://images.unsplash.com/photo-1735233024815-7986206a18a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxUaGFpJTIwUmVkJTIwQ3VycnklMjBib3dsfGVufDF8fHx8MTc2NDUwMDEzOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
          "https://images.unsplash.com/photo-1755742319537-449f661a3190?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aWJyYW50JTIwYXNpYW4lMjBzdHJlZXQlMjBmb29kJTIwZmVhc3QlMjBmbGF0JTIwbGF5JTIwaGlnaCUyMGNvbnRyYXN0JTIwcG9wJTIwY29sb3JzfGVufDF8fHx8MTc2NDUwMDY4MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
          "https://images.unsplash.com/photo-1752654976426-f0de0cbf8bb5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxDaGVmJTIwcG91cmluZyUyMGJyb3RoJTIwbm9vZGxlJTIwYm93bCUyMHN0ZWFtfGVufDF8fHx8MTc2NDUwMDEzOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
        ],
        drinks: [
          "https://images.unsplash.com/photo-1749169337822-d875fd6f4c9d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxDbG9zZSUyMHVwJTIwYXNpYW4lMjBub29kbGVzJTIwc3BpY3l8ZW58MXx8fHwxNzY0NTAwMTM4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
          "https://images.unsplash.com/photo-1608131922243-00b9ae767eec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTcGljZXMlMjBpbiUyMHNwb29ucyUyMGNvbG9yZnVsfGVufDF8fHx8MTc2NDUwMDEzOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
        ]
      },
      hero: "https://images.unsplash.com/photo-1755742319537-449f661a3190?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aWJyYW50JTIwYXNpYW4lMjBzdHJlZXQlMjBmb29kJTIwZmVhc3QlMjBmbGF0JTIwbGF5JTIwaGlnaCUyMGNvbnRyYXN0JTIwcG9wJTIwY29sb3JzfGVufDF8fHx8MTc2NDUwMDY4MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      menuPreview: [
        "https://images.unsplash.com/photo-1762305194201-077e7e23ccf2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxDcmlzcHklMjBUb2Z1JTIwYXNpYW4lMjBkaXNofGVufDF8fHx8MTc2NDUwMDEzOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1708782340377-882559d544fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxDaGlja2VuJTIwTWFzc2FtYW4lMjBjdXJyeSUyMGJvd2x8ZW58MXx8fHwxNzY0NTAwMTM5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1735233024815-7986206a18a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxUaGFpJTIwUmVkJTIwQ3VycnklMjBib3dsfGVufDF8fHx8MTc2NDUwMDEzOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      ],
      storyBlock: [
        "https://images.unsplash.com/photo-1608131922243-00b9ae767eec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTcGljZXMlMjBpbiUyMHNwb29ucyUyMGNvbG9yZnVsfGVufDF8fHx8MTc2NDUwMDEzOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1672172505672-babacdc28071?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBc2lhbiUyMHN0cmVldCUyMGZvb2QlMjBtYXJrZXQlMjBuaWdodHxlbnwxfHx8fDE3NjQ1MDAxMzl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1749169337822-d875fd6f4c9d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxDbG9zZSUyMHVwJTIwYXNpYW4lMjBub29kbGVzJTIwc3BpY3l8ZW58MXx8fHwxNzY0NTAwMTM4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      ],
      storyPageHero: "https://images.unsplash.com/photo-1556910103-1c02745a30bf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxDaGVmJTIwY29va2luZyUyMGFzaWFuJTIwZm9vZCUyMGtpY2hlbnxlbnwxfHx8fDE3NjQ1MDA5MTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      storyPage: [
        "https://images.unsplash.com/photo-1563245372-f21724e3856d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaW0lMjBzdW18ZW58MXx8fHwxNzY0NTAwOTEyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1541696490865-e6f720e96e97?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkdW1wbGluZ3N8ZW58MXx8fHwxNzY0NTAwOTEyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1511690656952-34342d5c28b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc2lhbiUyMGNoZWZ8ZW58MXx8fHwxNzY0NTAwOTEyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1504674900247-0877df9cc836?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc2lhbiUyMGZvb2R8ZW58MXx8fHwxNzY0NTAwOTEyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      ]
    },
    socials: [
      { platform: "Instagram", url: "#" },
      { platform: "Facebook", url: "#" },
      { platform: "Twitter", url: "#" }
    ]
  }
}

export const siteContent = { ...siteAssets, ...siteText }