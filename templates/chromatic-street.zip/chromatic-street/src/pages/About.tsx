
import React from "react";
import { siteContent } from "../data/content";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Footer } from "../components/Footer";

export function About() {
  const { storyPage, staticAssets } = siteContent;
  const images = staticAssets.images.storyPage ?? [];
  const heroImage = staticAssets.images.storyPageHero;
  const values = storyPage.values ?? []
  const valueColors = staticAssets.colors.storyPageValues ?? []

  return (
    <div className="min-h-screen bg-white">
      {/* About Hero */}
      <div className="bg-[#FF5722] p-12 md:p-24 border-b-4 border-black text-center">
        <h1 className="text-5xl md:text-8xl font-black text-white uppercase tracking-tighter mb-6">
          {storyPage.heading}
        </h1>
        <p className="text-xl font-bold text-white/90 max-w-2xl mx-auto">
          {storyPage.subhead}
        </p>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center mb-24">
          <div className="relative">
              <div className="border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] aspect-[4/5] overflow-hidden bg-gray-200">
                <ImageWithFallback
                  src={heroImage}
                  alt={storyPage.heroImageAlt}
                  className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500"
                />
              </div>
          </div>
          <div>
              <h2 className="text-4xl md:text-6xl font-black uppercase mb-8 leading-none text-[#2962FF]">
                {storyPage.content.heading}
              </h2>
              <div className="space-y-6 text-xl font-medium text-black/80 leading-relaxed">
                {storyPage.content.body.map((item, idx) => (
                  <p key={idx}>{item}</p>
                ))}
              </div>
          </div>
        </div>

        {/* Values Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-24">
            {values.map((value, idx) => (
                <div key={idx} className="p-8 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]" style={{ backgroundColor: valueColors[idx] }}>
                    <h3 className="text-3xl font-black uppercase mb-4">{value.title}</h3>
                    <p className="font-bold text-black/80 text-lg">{value.desc}</p>
                </div>
            ))}
        </div>
        
        {/* Image Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-24">
          {images.map((src, i) => (
            <div key={i} className="aspect-square border-4 border-black overflow-hidden grayscale hover:grayscale-0 transition-all duration-500">
              <ImageWithFallback src={src} alt="Kitchen atmosphere" className="w-full h-full object-cover" />
            </div>
          ))}
        </div>

      </div>
      <Footer />
    </div>
  );
}
