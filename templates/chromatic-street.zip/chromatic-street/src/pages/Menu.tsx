
import React from "react";
import { siteContent } from "../data/content";
import { Footer } from "../components/Footer";
import { MenuItem } from "../components/MenuItem";

export function Menu() {
  const { fullMenu, staticAssets } = siteContent
  const starterItems = fullMenu.starters.items ?? [];
  const mainItems = fullMenu.mains.items ?? [];
  const drinkItems = fullMenu.drinks.items ?? [];

  const starterImages = staticAssets.images.fullMenu.starters ?? [];
  const mainImages = staticAssets.images.fullMenu.mains ?? [];
  const drinkImages = staticAssets.images.fullMenu.drinks ?? [];
  return (
    <div className="bg-white min-h-screen">
      {/* Menu Hero */}
      <div className="bg-[#2962FF] p-12 md:p-24 border-b-4 border-black text-center">
        <h1 className="text-5xl md:text-8xl font-black text-white uppercase tracking-tighter mb-6">
          {fullMenu.heading}
        </h1>
        <p className="text-xl font-bold text-white/90 max-w-2xl mx-auto">
          {fullMenu.subhead}
        </p>
      </div>

      {/* Menu Sections */}
      <div className="container mx-auto px-4 py-16 space-y-16">
        
        {/* Starters */}
        <section>
          <h2 className="text-4xl font-black uppercase mb-8 border-l-8 border-[#FFEB3B] pl-6 py-2">
            {fullMenu.starters.title}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {starterItems.map((item, idx) => (
              <MenuItem key={item.id} item={item} image={starterImages[idx]}/>
            ))}
          </div>
        </section>

        {/* Mains */}
        <section>
          <h2 className="text-4xl font-black uppercase mb-8 border-l-8 border-[#FF5722] pl-6 py-2">
            {fullMenu.mains.title}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {mainItems.map((item, idx) => (
              <MenuItem key={item.id} item={item} image={mainImages[idx]} />
            ))}
          </div>
        </section>

        {/* Drinks */}
        <section>
          <h2 className="text-4xl font-black uppercase mb-8 border-l-8 border-[#2962FF] pl-6 py-2">
            {fullMenu.drinks.title}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {drinkItems.map((item, idx) => (
              <MenuItem key={item.id} item={item} image={drinkImages[idx]} />
            ))}
          </div>
        </section>
      </div>

      <Footer />
    </div>
  );
}
