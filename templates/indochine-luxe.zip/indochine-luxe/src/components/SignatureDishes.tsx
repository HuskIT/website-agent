import { siteContent } from "../data/content";
import { Link } from "react-router-dom";

export function SignatureDishes({ showCta = true }: { showCta?: boolean }) {
  return (
    <section id="menu" className="py-32 px-6 bg-[#1C1C1C]">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-24">
          <h2
            className="text-5xl md:text-6xl mb-6 tracking-wide"
            style={{ fontFamily: "var(--font-serif)" }}
          >
            {siteContent.menuHighlights.heading}
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto leading-relaxed">
            {siteContent.menuHighlights.subhead}
          </p>
          <div className="w-24 h-[1px] bg-[#C5A059] mx-auto mt-8" />
        </div>

        {/* Dishes Grid - Broken Layout */}
        <div className="space-y-32">
          {siteContent.menuHighlights.items.map((dish, index) => {
            const isReversed = index % 2 !== 0;
            return (
              <div
                key={dish.name}
                className={`grid md:grid-cols-2 gap-12 items-center ${
                  isReversed ? "md:grid-flow-dense" : ""
                }`}
              >
                {/* Image */}
                <div
                  className={`relative group ${isReversed ? "md:col-start-2" : ""}`}
                >
                  <div className="overflow-hidden">
                    <img
                      src={dish.imageSrc}
                      alt={dish.name}
                      className="w-full h-[500px] object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  </div>
                  {/* Gold Frame Effect */}
                  <div className="absolute inset-0 border border-[#C5A059]/30 pointer-events-none" />
                </div>

                {/* Text Content */}
                <div
                  className={`space-y-6 ${
                    isReversed ? "md:col-start-1 md:row-start-1 md:pr-12" : "md:pl-12"
                  }`}
                >
                  <div className="flex items-baseline justify-between gap-4">
                    <h3
                      className="text-3xl tracking-wide"
                      style={{ fontFamily: "var(--font-serif)" }}
                    >
                      {dish.name}
                    </h3>
                    <span className="text-2xl text-[#C5A059]" style={{ fontFamily: "var(--font-serif)" }}>
                      ${dish.price}
                    </span>
                  </div>
                  <div className="w-16 h-[1px] bg-[#C5A059]" />
                  <p className="text-lg text-gray-300 leading-relaxed italic">
                    {dish.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* CTA */}
        {showCta && (
          <div className="text-center mt-24">
            <Link
              to={siteContent.menuHighlights.cta.link}
              className="inline-block border-2 border-[#C5A059] text-[#C5A059] px-12 py-4 uppercase tracking-[0.2em] transition-all duration-500 hover:bg-[#C5A059] hover:text-[#1C1C1C]"
            >
              {siteContent.menuHighlights.cta.label}
            </Link>
          </div>
        )}
      </div>
    </section>
  );
}
