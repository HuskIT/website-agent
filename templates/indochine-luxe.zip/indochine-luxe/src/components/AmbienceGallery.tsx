import Masonry from "react-responsive-masonry";
import { siteContent } from "../data/content";
import { Link } from "react-router-dom";

const galleryImages = siteContent.gallery.images.slice(0,6)

export function AmbienceGallery({ showCta = true }: { showCta?: boolean }) {
  return (
    <section id="gallery" className="py-32 px-6 bg-[#2A2A2A]">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-24">
          <h2
            className="text-5xl md:text-6xl mb-6 tracking-wide"
            style={{ fontFamily: "var(--font-serif)" }}
          >
            {siteContent.gallery.heading}
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            {siteContent.gallery.subhead}
          </p>
          <div className="w-24 h-[1px] bg-[#C5A059] mx-auto mt-8" />
        </div>

        {/* Masonry Gallery */}
        <Masonry columnsCount={3} gutter="16px">
          {galleryImages.map((image, index) => (
            <div key={index} className="group relative overflow-hidden cursor-pointer">
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-auto transition-all duration-700 group-hover:scale-110"
              />
              {/* Hover Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#C5A059]/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              {/* Gold Frame on Hover */}
              <div className="absolute inset-0 border-2 border-[#C5A059] scale-95 opacity-0 group-hover:opacity-100 group-hover:scale-100 transition-all duration-500 pointer-events-none" />
            </div>
          ))}
        </Masonry>

        {/* CTA */}
        {showCta && (
          <div className="text-center mt-16">
            <Link
              to={siteContent.gallery.cta.link}
              className="inline-block border-2 border-[#C5A059] text-[#C5A059] px-12 py-4 uppercase tracking-[0.2em] transition-all duration-500 hover:bg-[#C5A059] hover:text-[#1C1C1C]"
            >
              {siteContent.gallery.cta.label}
            </Link>
          </div>
        )}
      </div>
    </section>
  );
}
