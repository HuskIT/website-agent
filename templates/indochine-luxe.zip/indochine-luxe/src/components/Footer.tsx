import { Instagram, Facebook } from "lucide-react";
import { siteContent } from "../data/content";

export function Footer() {
  return (
    <footer className="bg-[#1C1C1C] border-t border-[#C5A059]/20 py-16 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Main Footer Content */}
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div>
            <h3
              className="text-2xl mb-4 tracking-[0.3em] uppercase"
              style={{ fontFamily: "var(--font-serif)" }}
            >
              {siteContent.branding.name}
            </h3>
            <p className="text-gray-400 leading-relaxed">
              {siteContent.branding.slogan}
            </p>
          </div>

          {/* Hours */}
          <div>
            <h4 className="text-[#C5A059] uppercase tracking-wider mb-4">
              {siteContent.common.hours}
            </h4>
            <div className="space-y-2">
              {siteContent.footer.hours.map((schedule, index) => (
                <div key={index} className="text-gray-400">
                  <span className="block">{schedule.days}</span>
                  <span className="block text-gray-500">{schedule.time}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Connect */}
          <div>
            <h4 className="text-[#C5A059] uppercase tracking-wider mb-4">
              {siteContent.common.connect}
            </h4>
            <div className="space-y-4">
              <p className="text-gray-400">{siteContent.contact.email}</p>
              <p className="text-gray-400">{siteContent.contact.phone}</p>
              <div className="flex gap-4 pt-4">
                {siteContent.socials.map((social) => (
                  <a
                    key={social.platform}
                    href={social.url}
                    className="w-10 h-10 border border-[#C5A059] flex items-center justify-center transition-all duration-300 hover:bg-[#C5A059] hover:text-[#1C1C1C]"
                    aria-label={social.platform}
                  >
                    {social.platform === "Instagram" && <Instagram size={18} />}
                    {social.platform === "Facebook" && <Facebook size={18} />}
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-[#C5A059]/20 text-center">
          <p className="text-gray-500 text-sm">
            © {new Date().getFullYear()} {siteContent.footer.copyright}
          </p>
        </div>
      </div>
    </footer>
  );
}
