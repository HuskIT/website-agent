import { siteContent } from "../data/content";
import { Link } from "react-router-dom";

export function HeroSection() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src={siteContent.hero.backgroundImage.src}
          alt={siteContent.hero.backgroundImage.alt}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-[#1C1C1C]" />
        
        {/* Subtle Gold Pattern Overlay */}
        <div
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M30 0l4 8h8l-6 6 2 8-8-4-8 4 2-8-6-6h8z' fill='%23C5A059' fill-opacity='1' fill-rule='evenodd'/%3E%3C/svg%3E")`,
          }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-4xl">
        <p className="uppercase tracking-[0.3em] mb-6 text-[#C5A059]">
          {siteContent.hero.eyebrow}
        </p>
        <h1
          className="text-6xl md:text-8xl mb-8 tracking-wider"
          style={{ fontFamily: "var(--font-serif)" }}
        >
          {siteContent.hero.headline}
        </h1>
        <p className="text-xl md:text-2xl mb-12 text-gray-300 max-w-2xl mx-auto leading-relaxed">
          {siteContent.hero.subhead}
        </p>
        <Link
          to={siteContent.hero.cta.link}
          className="inline-block border border-[#C5A059] text-[#C5A059] px-12 py-4 uppercase tracking-[0.2em] transition-all duration-500 hover:bg-[#C5A059] hover:text-[#1C1C1C]"
        >
          {siteContent.hero.cta.label}
        </Link>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-10">
        <div className="w-[1px] h-16 bg-gradient-to-b from-[#C5A059] to-transparent" />
      </div>
    </section>
  );
}
