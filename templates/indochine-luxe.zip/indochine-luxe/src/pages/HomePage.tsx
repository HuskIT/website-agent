import { HeroSection } from "../components/HeroSection";
import { SignatureDishes } from "../components/SignatureDishes";
import { IngredientOrigin } from "../components/IngredientOrigin";
import { HeritageSection } from "../components/HeritageSection";
import { AmbienceGallery } from "../components/AmbienceGallery";
import { ReservationsCTA } from "../components/ReservationsCTA";

export function HomePage() {
  return (
    <main>
      <HeroSection />
      <SignatureDishes />
      <IngredientOrigin />
      <HeritageSection />
      <AmbienceGallery />
      <ReservationsCTA />
    </main>
  );
}
