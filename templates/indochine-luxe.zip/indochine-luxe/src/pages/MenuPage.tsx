import { SignatureDishes } from "../components/SignatureDishes";
import { FullMenu } from "../components/FullMenu";

export function MenuPage() {
  return (
    <main className="pt-24 bg-[#1C1C1C] min-h-screen">
       {/* Highlights Section */}
       <SignatureDishes showCta={false} />
       
       {/* Divider */}
       <div className="max-w-2xl mx-auto px-6">
         <div className="h-[1px] bg-gradient-to-r from-transparent via-[#C5A059]/50 to-transparent" />
       </div>

       {/* Full Menu */}
       <FullMenu />
    </main>
  );
}
