import React from 'react';
import { siteContent } from '../../data/content';
import { HeavyButton } from '../ui/HeavyButton';
import { motion } from 'motion/react';

interface HeavyMenuGridProps {
  onNavigate: (page: string) => void;
  isFullPage?: boolean;
}

export const HeavyMenuGrid: React.FC<HeavyMenuGridProps> = ({ onNavigate, isFullPage = false }) => {
  const { menuHighlights, staticAssets } = siteContent;
  const menuItems = menuHighlights.items ?? [];
  const images = staticAssets.images.menuHighlights ?? [];

  return (
    <section className="py-24 bg-black text-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 pb-4 border-b-4 border-stone-800">
          <div>
             <h2 className="text-5xl md:text-7xl font-black uppercase tracking-tighter leading-none">
              {isFullPage ? menuHighlights.fullMenu : menuHighlights.fanFavorites}
            </h2>
            <p className="text-orange-600 font-bold uppercase tracking-widest mt-2">
              {isFullPage ? menuHighlights.eatLikeYouMeanIt : menuHighlights.heading}
            </p>
          </div>
          {!isFullPage && (
            <HeavyButton variant="outline" className="hidden md:block mt-4 md:mt-0" onClick={() => onNavigate('menu')}>
              {menuHighlights.viewFullMenu}
            </HeavyButton>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {menuItems.map((item, idx) => {
            const badges = item.badges ?? [];
            return (
            <motion.div 
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group bg-stone-900 hover:bg-stone-800 transition-colors duration-300 overflow-hidden"
            >
              <div className="aspect-[4/3] overflow-hidden relative">
                 <img 
                  src={images[idx]} 
                  alt={item.name}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 filter brightness-90 group-hover:brightness-100 contrast-125"
                />
                <div className="absolute top-4 right-4 flex flex-col gap-2">
                  {badges.map(badge => (
                    <span key={badge} className="bg-orange-600 text-black text-xs font-black px-3 py-1 uppercase transform rotate-2">
                      {badge}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="p-6 border-l-4 border-transparent group-hover:border-orange-600 transition-colors">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-2xl font-black uppercase leading-tight max-w-[80%]">{item.name}</h3>
                  <span className="text-2xl font-black text-orange-600">{item.price}</span>
                </div>
                <p className="text-stone-400 text-sm font-medium leading-relaxed mb-6">
                  {item.description}
                </p>
                
                {/* Visual Only - No Functionality */}
                <div className="w-full py-3 text-center border border-stone-700 text-stone-500 uppercase text-xs font-bold tracking-widest group-hover:border-stone-500 group-hover:text-white transition-colors cursor-pointer">
                  {menuHighlights.viewItemDetails}
                </div>
              </div>
            </motion.div>
            )
          })}
        </div>
        
        {!isFullPage && (
          <div className="mt-12 md:hidden">
            <HeavyButton variant="outline" className="w-full" onClick={() => onNavigate('menu')}>
              {menuHighlights.viewFullMenu}
            </HeavyButton>
          </div>
        )}
      </div>
    </section>
  );
};
