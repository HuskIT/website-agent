import * as React from "react"
import { cn } from "../../lib/utils"

interface HeavyButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline'
}

export const HeavyButton = React.forwardRef<HTMLButtonElement, HeavyButtonProps>(
  ({ className, variant = 'primary', ...props }, ref) => {
    const variants = {
      primary: "bg-orange-600 text-black hover:bg-orange-500 border-transparent",
      secondary: "bg-stone-800 text-white hover:bg-stone-700 border-transparent",
      outline: "bg-transparent text-white border-2 border-white hover:bg-white hover:text-black"
    }

    return (
      <button
        ref={ref}
        className={cn(
          "px-8 py-4 font-black text-lg uppercase tracking-wider transition-all duration-200 transform active:scale-95 focus:outline-none focus:ring-4 focus:ring-orange-600 focus:ring-offset-2 focus:ring-offset-black",
          variants[variant],
          className
        )}
        {...props}
      />
    )
  }
)
HeavyButton.displayName = "HeavyButton"
