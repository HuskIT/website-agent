import React from 'react';
import { siteContent } from '../../data/content';
import { Menu, X } from 'lucide-react';
import { HeavyButton } from '../ui/HeavyButton';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPage, onNavigate }) => {
  const [isOpen, setIsOpen] = React.useState(false);
  const { branding, navigation } = siteContent

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/95 border-b border-stone-800 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div 
            className="text-3xl font-black text-white tracking-tighter cursor-pointer uppercase select-none"
            onClick={() => onNavigate('home')}
          >
            {branding.name}
            <span className="text-orange-600">{branding.punct}</span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            {navigation.map((item) => {
              if (item.isCtaButton) {
                return (
                  <HeavyButton 
                    key={item.path}
                    variant="primary" 
                    className="py-2 px-6 text-sm"
                    onClick={() => onNavigate(item.path)}
                  >
                    {item.label}
                  </HeavyButton>
                );
              }

              return (
                <button
                  key={item.path}
                  onClick={() => onNavigate(item.path)}
                  className={`text-sm font-bold tracking-widest uppercase hover:text-orange-500 transition-colors ${
                    currentPage === item.path ? 'text-orange-600' : 'text-stone-300'
                  }`}
                >
                  {item.label}
                </button>
              )
            })}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-white p-2">
              {isOpen ? <X size={32} /> : <Menu size={32} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden absolute top-20 left-0 w-full bg-black border-b border-stone-800 p-4 flex flex-col space-y-4">
           {navigation.map((item) => {
            if (item.isCtaButton) {
              return (
                <HeavyButton
                  key={item.path}
                  variant="primary" 
                  className="w-full"
                  onClick={() => {
                    onNavigate(item.path);
                    setIsOpen(false);
                  }}
                >
                  {item.label}
                </HeavyButton>
              )
            }
            return (
              <button
                key={item.path}
                onClick={() => {
                  onNavigate(item.path);
                  setIsOpen(false);
                }}
                className={`text-xl font-black uppercase text-left py-2 ${
                   currentPage === item.path ? 'text-orange-600' : 'text-white'
                }`}
              >
                {item.label}
              </button>
            )})}
        </div>
      )}
    </nav>
  );
};
