import React from 'react';
import { siteContent } from '../../data/content';

export const Footer: React.FC = () => {
  const { branding, footer } = siteContent;
  const socials = footer.socials ?? [];
  
  return (
    <footer className="bg-black text-stone-400 py-12 border-t border-stone-900">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
        <div>
          <h3 className="text-white text-2xl font-black uppercase mb-4">{branding.name}<span className="text-orange-600">{branding.punct}</span></h3>
          <p className="text-sm font-mono uppercase tracking-wide">{footer.address}</p>
        </div>
        
        <div>
           <h4 className="text-white text-lg font-bold uppercase mb-4">{footer && footer.hours ? 'Hours' : 'Hours'}</h4>
           <p className="text-sm font-mono uppercase tracking-wide">{footer.hours}</p>
        </div>

        <div>
          <h4 className="text-white text-lg font-bold uppercase mb-4">{footer.followUs}</h4>
          <div className="flex justify-center md:justify-start space-x-4">
            {socials.map((social) => (
              <a key={social} href="#" className="text-sm font-mono uppercase tracking-wide hover:text-orange-600 transition-colors">
                {social}
              </a>
            ))}
          </div>
        </div>
      </div>
      <div className="mt-12 text-center text-xs uppercase text-stone-700 tracking-widest">
        © {new Date().getFullYear()} {branding.name}{branding.punct} {footer.rights}
      </div>
    </footer>
  );
};
