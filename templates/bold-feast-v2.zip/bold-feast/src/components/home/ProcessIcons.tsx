import React from 'react';
import { siteContent } from '../../data/content';
import { Flame, Utensils, Clock } from 'lucide-react';

const iconMap = {
  Flame: Flame,
  Knife: Utensils,
  Drumstick: Clock
};

export const ProcessIcons: React.FC = () => {
  const { process } = siteContent;
  const steps = process.steps ?? [];

  return (
    <section className="py-24 bg-stone-950 text-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
           <h2 className="text-5xl md:text-7xl font-black uppercase tracking-tighter mb-4 text-white">
            {process.title}
          </h2>
          <div className="w-24 h-2 bg-orange-600 mx-auto mb-6" />
          <p className="text-stone-400 text-lg max-w-2xl mx-auto uppercase tracking-wide">
            {process.description}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative z-10">
          {steps.map((step, index) => {
            const Icon = iconMap[step.icon as keyof typeof iconMap];
            return (
              <div key={index} className="flex flex-col items-center text-center group">
                <div className="w-32 h-32 rounded-full border-4 border-stone-800 flex items-center justify-center mb-6 group-hover:border-orange-600 transition-colors duration-300 bg-black">
                  <Icon size={48} className="text-stone-300 group-hover:text-orange-600 transition-colors" />
                </div>
                <h3 className="text-2xl font-black uppercase mb-2">{step.title}</h3>
                <p className="text-stone-500 font-mono uppercase text-sm tracking-wider">{step.description}</p>
              </div>
            );
          })}
        </div>
      </div>
       {/* Subtle smoke texture or gradient */}
       <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-black to-transparent pointer-events-none" />
    </section>
  );
};
