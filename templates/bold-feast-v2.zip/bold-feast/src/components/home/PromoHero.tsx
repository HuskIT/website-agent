import React from 'react';
import { siteContent } from '../../data/content';
import { HeavyButton } from '../ui/HeavyButton';
import { motion } from 'motion/react';

interface PromoHeroProps {
  onNavigate: (page: string) => void;
}

export const PromoHero: React.FC<PromoHeroProps> = ({ onNavigate }) => {
  const { hero, staticAssets } = siteContent;

  return (
    <section className="relative h-[90vh] w-full overflow-hidden bg-black flex items-center justify-center">
      {/* Background Image with Heavy Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src={staticAssets.images.hero} 
          alt={hero.imageAlt} 
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
        <div className="absolute inset-0 bg-black/20" style={{ backdropFilter: 'contrast(120%)' }} />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 text-center">
        <motion.h1 
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-6xl md:text-8xl lg:text-9xl font-black text-white leading-[0.9] tracking-tighter uppercase mb-6 drop-shadow-2xl"
        >
          {hero.headline.split('. ').map((part, i) => (
            <span key={i} className="block md:inline md:mr-4 text-shadow-lg">
              {part}{i < 2 ? '.' : ''}
            </span>
          ))}
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="text-xl md:text-2xl text-stone-200 max-w-3xl mx-auto mb-10 font-medium uppercase tracking-wide text-shadow"
        >
          {hero.subhead}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.6 }}
        >
          <HeavyButton onClick={() => onNavigate(hero.cta.link)}>
            {hero.cta.label}
          </HeavyButton>
        </motion.div>
      </div>

      {/* Texture Overlay (simulated with CSS) */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.15] bg-[url('https://www.transparenttextures.com/patterns/shattered-island.png')] mix-blend-overlay" />
    </section>
  );
};
