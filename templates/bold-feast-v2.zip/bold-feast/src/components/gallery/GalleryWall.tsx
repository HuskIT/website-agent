import React from 'react';
import { siteContent } from '../../data/content';
import Masonry, { ResponsiveMasonry } from "react-responsive-masonry";
import { HeavyButton } from '../ui/HeavyButton';

interface GalleryWallProps {
  onNavigate: (page: string) => void;
  isFullPage?: boolean;
}

export const GalleryWall: React.FC<GalleryWallProps> = ({ onNavigate, isFullPage = false }) => {
  const { gallery, galleryTeaser, staticAssets } = siteContent;
  const images = staticAssets.images.galleryTeaser ?? [];
  
  // Duplicate images to simulate a larger gallery if on full page
  const galleryImages = isFullPage 
    ? [...staticAssets.images.galleryTeaser, ...staticAssets.images.galleryTeaser, ...staticAssets.images.galleryTeaser]
    : staticAssets.images.galleryTeaser;

  return (
    <section className="py-24 bg-stone-950 text-white border-t border-stone-900">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16">
           <div className="max-w-2xl">
             <h2 className="text-5xl md:text-7xl font-black uppercase tracking-tighter leading-none mb-4">
              {isFullPage ? gallery.atmosphere : gallery.scene}
            </h2>
             <p className="text-stone-400 text-lg uppercase tracking-wide">
              {gallery.intro}
            </p>
          </div>
          {!isFullPage && (
            <HeavyButton variant="secondary" onClick={() => onNavigate('gallery')}>
              {gallery.viewFullGallery}
            </HeavyButton>
          )}
        </div>

        <ResponsiveMasonry
          columnsCountBreakPoints={{350: 1, 750: 2, 900: 3}}
        >
          <Masonry gutter="1rem">
            {galleryImages.map((image, i) => (
              <div key={i} className="relative group overflow-hidden bg-stone-900">
                <img
                  src={image}
                  style={{width: "100%", display: "block"}}
                  alt="Gallery"
                  className="grayscale group-hover:grayscale-0 transition-all duration-500 scale-100 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-orange-600/0 group-hover:bg-orange-600/20 transition-colors duration-300 pointer-events-none" />
              </div>
            ))}
          </Masonry>
        </ResponsiveMasonry>
        
        {!isFullPage && (
           <div className="mt-12 text-center md:hidden">
              <HeavyButton variant="secondary" className="w-full" onClick={() => onNavigate('gallery')}>
                {gallery.viewFullGallery}
              </HeavyButton>
           </div>
        )}
      </div>
    </section>
  );
};
