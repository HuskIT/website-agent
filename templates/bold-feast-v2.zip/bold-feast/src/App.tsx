import React, { useState, useEffect } from 'react';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { PromoHero } from './components/home/PromoHero';
import { ProcessIcons } from './components/home/ProcessIcons';
import { HeavyMenuGrid } from './components/menu/HeavyMenuGrid';
import { GalleryWall } from './components/gallery/GalleryWall';
import { siteContent } from './data/content';

const ScrollToTop = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return null;
};

const HomePage = ({ onNavigate }: { onNavigate: (page: string) => void }) => (
  <>
    <ScrollToTop />
    <PromoHero onNavigate={onNavigate} />
    <ProcessIcons />
    <HeavyMenuGrid onNavigate={onNavigate} />
    <GalleryWall onNavigate={onNavigate} />
  </>
);

const MenuPage = ({ onNavigate }: { onNavigate: (page: string) => void }) => (
  <>
    <ScrollToTop />
    <div className="pt-20 bg-black min-h-screen">
      <div className="py-20 bg-stone-900 text-center">
         <h1 className="text-6xl md:text-8xl font-black text-white uppercase tracking-tighter">{siteContent.menuHighlights.title}</h1>
      </div>
      <HeavyMenuGrid onNavigate={onNavigate} isFullPage={true} />
    </div>
  </>
);

const GalleryPage = ({ onNavigate }: { onNavigate: (page: string) => void }) => (
  <>
    <ScrollToTop />
     <div className="pt-20 bg-black min-h-screen">
       <div className="py-20 bg-stone-900 text-center">
         <h1 className="text-6xl md:text-8xl font-black text-white uppercase tracking-tighter">{siteContent.gallery.title}</h1>
      </div>
      <GalleryWall onNavigate={onNavigate} isFullPage={true} />
    </div>
  </>
);

const LocationsPage = () => (
  <>
    <ScrollToTop />
     <div className="pt-20 bg-black min-h-screen flex items-center justify-center text-center px-4">
        <div>
          <h1 className="text-6xl md:text-8xl font-black text-white uppercase tracking-tighter mb-8">{siteContent.locations.title}</h1>
          <div className="text-2xl text-stone-400 font-mono uppercase tracking-widest space-y-4">
            {siteContent.locations.addresses.map((address, index) => (
              <p key={index}>{address}</p>
            ))}
          </div>
        </div>
    </div>
  </>
);

const ReservationsPage = () => {
  const { reservations } = siteContent
  const formOptions = reservations.form.options ?? []

  return (
  <>
    <ScrollToTop />
    <div className="pt-20 bg-black min-h-screen flex items-center justify-center px-4">
      <div className="max-w-2xl w-full py-20">
        <div className="text-center mb-12">
          <h1 className="text-5xl md:text-7xl font-black text-white uppercase tracking-tighter mb-4">{reservations.title}</h1>
          <p className="text-stone-400 text-lg uppercase tracking-wide">{reservations.subtitle}</p>
        </div>
        
        <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); alert(reservations.form.alertMessage); }}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-stone-500 text-xs font-bold uppercase tracking-widest mb-2">{reservations.form.name}</label>
              <input
                type="text"
                className="w-full bg-stone-900 border-2 border-stone-800 text-white px-4 py-3 focus:outline-none focus:border-orange-600 transition-colors uppercase font-bold"
                placeholder={reservations.form.placeholders.name}
              />
            </div>
            <div>
              <label className="block text-stone-500 text-xs font-bold uppercase tracking-widest mb-2">{reservations.form.phone}</label>
              <input
                type="tel"
                className="w-full bg-stone-900 border-2 border-stone-800 text-white px-4 py-3 focus:outline-none focus:border-orange-600 transition-colors uppercase font-bold"
                placeholder={reservations.form.placeholders.phone}
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
             <div>
              <label className="block text-stone-500 text-xs font-bold uppercase tracking-widest mb-2">{reservations.form.date}</label>
              <input type="date" className="w-full bg-stone-900 border-2 border-stone-800 text-white px-4 py-3 focus:outline-none focus:border-orange-600 transition-colors uppercase font-bold" />
            </div>
             <div>
              <label className="block text-stone-500 text-xs font-bold uppercase tracking-widest mb-2">{reservations.form.time}</label>
              <input type="time" className="w-full bg-stone-900 border-2 border-stone-800 text-white px-4 py-3 focus:outline-none focus:border-orange-600 transition-colors uppercase font-bold" />
            </div>
             <div>
              <label className="block text-stone-500 text-xs font-bold uppercase tracking-widest mb-2">{reservations.form.guests}</label>
              <select className="w-full bg-stone-900 border-2 border-stone-800 text-white px-4 py-3 focus:outline-none focus:border-orange-600 transition-colors uppercase font-bold appearance-none">
                {formOptions.map((option, index) => (
                  <option key={index}>{option}</option>
                ))}
              </select>
            </div>
          </div>
          
          <button type="submit" className="w-full bg-orange-600 text-black font-black uppercase text-xl py-4 hover:bg-orange-500 transition-colors mt-8">
            {reservations.form.submit}
          </button>
          
          <p className="text-center text-stone-600 text-xs uppercase tracking-widest mt-4">
            {reservations.form.disclaimer}
          </p>
        </form>
      </div>
    </div>
  </>
)};

function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    switch(currentPage) {
      case 'home': return <HomePage onNavigate={setCurrentPage} />;
      case 'menu': return <MenuPage onNavigate={setCurrentPage} />;
      case 'gallery': return <GalleryPage onNavigate={setCurrentPage} />;
      case 'locations': return <LocationsPage />;
      case 'reservations': return <ReservationsPage />;
      default: return <HomePage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-orange-600 selection:text-white">
      <Navbar currentPage={currentPage} onNavigate={setCurrentPage} />
      <main>
        {renderPage()}
      </main>
      <Footer />
    </div>
  );
}

export default App;
