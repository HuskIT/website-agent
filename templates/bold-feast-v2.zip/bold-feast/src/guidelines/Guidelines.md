# Project Guidelines: THE BOLD FEAST (The Grill)

## 1. Project Overview
**Concept:** A digital expression of hunger. The site is designed to be visceral, "heavy," and high-contrast to trigger appetite. It avoids typical e-commerce flows in favor of a raw, browsing-focused experience.

**Key Aesthetics:**
*   **Visceral:** Food is presented in extreme close-ups (macro photography).
*   **Industrial:** Textures of slate, smoke, and wood grain.
*   **Loud:** Uppercase typography, high contrast, and aggressive spacing.
*   **No E-commerce:** The goal is to drive foot traffic, not online orders.

## 2. Tech Stack
*   **Framework:** React (Vite)
*   **Styling:** Tailwind CSS
*   **Icons:** Lucide React
*   **Animation:** Motion (Framer Motion)
*   **Layout:** React Responsive Masonry (for galleries)

## 3. Design System & Tokens

### Colors
*   **Backgrounds:**
    *   `bg-black`: Main page background.
    *   `bg-stone-900`: Section breaks, cards, and panels.
    *   `bg-stone-950`: Darker section backgrounds.
*   **Accents:**
    *   `text-orange-600` / `bg-orange-600`: Primary Call-to-Action (CTA), highlights, and hover states. Represents fire/heat.
*   **Text:**
    *   `text-white`: Primary headings.
    *   `text-stone-400`: Body text, supporting details.

### Typography
*   **Headings:** Uppercase, Black/Bold weight, Tight tracking (`tracking-tighter`).
    *   *Usage:* `font-black uppercase tracking-tighter`
*   **Body:** Sans-serif, clean, often uppercase or mono-styled for labels.
    *   *Usage:* `font-medium uppercase tracking-wide` or `font-mono`

### UI Patterns
*   **Heavy Button:** Rectangular, sharp edges, solid fill. No rounded corners.
    *   *Component:* `HeavyButton.tsx`
*   **Card Hover:** Images zoom/scale slightly (`scale-105`), borders light up (`border-orange-600`).
*   **Separators:** Thick borders (`border-b-4 border-stone-800`) or solid colored lines (`w-24 h-2 bg-orange-600`).

## 4. Project Structure

```
/src
  /components
    /gallery    # Gallery layouts (Masonry)
    /home       # Homepage specific sections (Hero, Process)
    /layout     # Global layout (Navbar, Footer)
    /menu       # Menu grids and item cards
    /ui         # Reusable UI primitives (HeavyButton)
  /data
    content.ts  # Centralized data source (Text, Images, SEO)
  /lib
    utils.ts    # Utility functions (cn for class merging)
  App.tsx       # Main Routing & Page Composition
```

## 5. Coding Standards

### Data Driven
*   **Single Source of Truth:** All text content, navigation links, and image URLs must be stored in `/data/content.ts`.
*   **No Hardcoding:** Components should accept data as props or import from `siteContent`.

### Styling
*   **Tailwind-First:** Use utility classes for 100% of styling.
*   **Avoid Magic Numbers:** Use Tailwind's spacing scale (e.g., `py-24`, `gap-8`).
*   **Mobile-First:** Always define base styles for mobile, then use `md:` and `lg:` modifiers (e.g., `text-5xl md:text-7xl`).

### Images
*   **Quality:** High-resolution, appetizing imagery is critical.
*   **Fallback:** Ensure images look good even if they load slowly (dark backgrounds behind them).
*   **Textures:** Use CSS overlays or background images to add "grit" (noise, smoke).

### Routing
*   **Simple State Routing:** The current app uses a simple `useState` switch in `App.tsx` for navigation (`home`, `menu`, `gallery`, `locations`, `reservations`).
*   **Scroll Management:** Ensure `ScrollToTop` logic fires on every route change.

## 6. Extension Guidelines
*   **Adding Pages:**
    1.  Create the component in `App.tsx` or a new file.
    2.  Add the route case in the `renderPage` switch.
    3.  Update `siteContent.navigation` if it needs to appear in the navbar.
*   **Adding Components:**
    *   Keep them "Heavy." Avoid thin lines, rounded corners (unless circular for icons), or delicate shadows.
    *   Ensure they are fully responsive.
*   **Tone of Voice:**
    *   Confident, short, and punchy.
    *   Example: Instead of "Please view our delicious menu," use "FEAST YOUR EYES."
