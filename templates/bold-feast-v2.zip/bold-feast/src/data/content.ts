const siteText = {
  seo: {
    title: "THE GRILL | Messy. Meaty. Mighty.",
    metaDescription: "A visceral dining experience for the hungry. Wood-fired steaks, smashed burgers, and low & slow BBQ.",
  },
  navigation: [
    { label: "HOME", path: "home" },
    { label: "MENU", path: "menu" },
    { label: "GALLERY", path: "gallery" },
    { label: "LOCATIONS", path: "locations" },
    { label: "Book Table", path: "reservations", isCtaButton: true}
  ],
  hero: {
    headline: "MESSY. MEATY. MIGHTY.",
    subhead: "The ultimate feast for the carnivore soul. Wood-fired, smoke-kissed, and served with zero apologies.",
    cta: { label: "VIEW MENU", link: "menu" },
    imageAlt: "Extreme close-up of a juicy burger with dripping sauce"
  },
  process: {
    title: "FIRE & FURY",
    description: "We don't use timers. We use instinct. Our pitmasters smoke meat low and slow over hickory and oak until it falls off the bone.",
    steps: [
      { icon: "Flame", title: "WOOD FIRED", description: "Oak & Hickory logs only." },
      { icon: "Knife", title: "HAND CUT", description: "Butchered daily in-house." },
      { icon: "Drumstick", title: "LOW & SLOW", description: "Smoked for 12+ hours." }
    ]
  },
  menuHighlights: {
    heading: "THE PITMASTER'S CHOICE",
    cta: "VIEW FULL MENU",
    fullMenu: "Full Menu",
    fanFavorites: "Fan Favorites",
    eatLikeYouMeanIt: "Eat like you mean it",
    title: "Our Menu",
    viewFullMenu: "View Full Menu",
    viewItemDetails: "View Item Details",
    items: [
      {
        id: 1,
        name: "THE BEAST BURGER",
        price: "$24",
        description: "Double smash patty, thick-cut bacon, smoked gouda, caramelized onions, house bourbon BBQ sauce.",
        badges: ["SPICY", "NEW"]
      },
      {
        id: 2,
        name: "TOMAHAWK RIBEYE",
        price: "$85",
        description: "32oz bone-in ribeye, dry-aged for 45 days, seared over open flame. Served with chimichurri.",
        badges: ["SIGNATURE"]
      },
      {
        id: 3,
        name: "SMOKED BRISKET PLATE",
        price: "$32",
        description: "Half-pound of 14-hour smoked brisket, thick slices, pickles, onions, texas toast.",
        badges: []
      }
    ]
  },
  galleryTeaser: {
    heading: "THE SCENE",
    cta: "VIEW GALLERY",
  },
  branding: {
    name: "The Grill",
    punct: "."
  },
  gallery: {
    scene: "The Scene",
    title: "Gallery",
    atmosphere: "The Atmosphere",
    intro: "Loud music, cold drinks, and hot fire. This is where the magic happens.",
    viewFullGallery: "View Full Gallery"
  },
  footer: {
    address: "88 INDUSTRIAL AVE, MEATPACKING DISTRICT",
    hours: "DAILY: 11AM - LATE",
    socials: ["INSTAGRAM", "FACEBOOK"],
    rights: "All rights reserved.",
    followUs: "Follow Us"
  },
  locations: {
    title: "Locations",
    addresses: [
      "88 Industrial Ave, Meatpacking District",
      "102 Smokehouse Lane, Downtown",
      "Coming Soon: Westside Yard"
    ],
    hours: "DAILY: 11AM - LATE",
    findUs: "Find Us Here"
  },
  reservations: {
    title: "Book a Table",
    subtitle: "We don't do tiny portions. Bring an appetite.",
    form: {
      name: "Name",
      phone: "Phone",
      date: "Date",
      time: "Time",
      guests: "Guests",
      placeholders: {
        name: "JOHN DOE",
        phone: "(555) 000-0000"
      },
      options: ["2 People", "4 People", "6 People", "8+ (Call Us)"],
      submit: "Request Reservation",
      alertMessage: "Table Request Received. We will call you to confirm.",
      disclaimer: "* This is a demo request form. No actual reservation will be made."
    }
  }
};

const siteAsset = {
  staticAssets: {
    images: {
      galleryTeaser: [
        "https://images.unsplash.com/photo-1717912973650-59604d5659bd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGVha2hvdXNlJTIwaW5kdXN0cmlhbCUyMGludGVyaW9yJTIwZGFyayUyMHJ1c3RpY3xlbnwxfHx8fDE3NjQ0NzQzMTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1663744533041-353b72ff8959?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYnElMjByaWJzJTIwb24lMjBncmlsbCUyMHdpdGglMjBmaXJlJTIwYW5kJTIwc21va2V8ZW58MXx8fHwxNzY0NDc0MzEzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1532460854099-4de86fea4a11?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVmJTIwc2xpY2luZyUyMGJyaXNrZXQlMjB3b29kJTIwY3V0dGluZyUyMGJvYXJkfGVufDF8fHx8MTc2NDQ3NDMxM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      ],
      hero: "https://images.unsplash.com/photo-1634737118699-8bbb06e3fa2a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZWxpY2lvdXMlMjBidXJnZXIlMjBtYWNybyUyMGNsb3NlJTIwdXAlMjBkcmlwcGluZyUyMHNhdWNlJTIwZGFyayUyMGJhY2tncm91bmR8ZW58MXx8fHwxNzY0NDc0MzEyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      menuHighlights: [
        "https://images.unsplash.com/photo-1716235597777-0cc19943ca48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmFmdCUyMGJ1cmdlciUyMGFuZCUyMGZyaWVzJTIwZmVhc3QlMjB3b29kJTIwdGFibGV8ZW58MXx8fHwxNzY0NDc0MzEzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1719329466280-30d8a22e7cb5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbG9zZSUyMHVwJTIwc3RlYWslMjB0ZXh0dXJlJTIwcmF3JTIwb3IlMjBjb29rZWR8ZW58MXx8fHwxNzY0NDc0MzEzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1532460854099-4de86fea4a11?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVmJTIwc2xpY2luZyUyMGJyaXNrZXQlMjB3b29kJTIwY3V0dGluZyUyMGJvYXJkfGVufDF8fHx8MTc2NDQ3NDMxM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      ]
    }
  }
}

export const siteContent = {...siteText, ...siteAsset};