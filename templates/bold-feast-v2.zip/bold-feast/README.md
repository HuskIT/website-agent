
  # Bold Feast Design System

  This is a code bundle for Bold Feast Design System. The original project is available at https://www.figma.com/design/SSQoEuH09aew8KOudrdcH9/Bold-Feast-Design-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  