import React from 'react';
import Masonry, { ResponsiveMasonry } from "react-responsive-masonry";
import { motion } from 'motion/react';
import { siteContent } from '../data/content';

export const Gallery = () => {
  const { galleryPage, staticAssets } = siteContent;
  const images = staticAssets.images.gallery ?? [];

  return (
    <div className="min-h-screen py-20 px-4">
       <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="font-script text-6xl text-[#8C3A28] mb-4">{galleryPage.title}</h1>
            <p className="font-serif text-[#4A3B32]/80 text-lg">{galleryPage.subtitle}</p>
          </div>

          <ResponsiveMasonry columnsCountBreakPoints={{350: 1, 750: 2, 900: 3}}>
            <Masonry gutter="20px">
              {images.map((image, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="relative group overflow-hidden rounded-sm shadow-md bg-white p-2 pb-8"
                >
                  <img
                    src={image}
                    style={{width: "100%", display: "block"}}
                    alt={`${galleryPage.imageAltPrefix} ${i + 1}`}
                    className="filter grayscale-[0.2] contrast-[0.95] group-hover:grayscale-0 transition-all duration-500"
                  />
                  <div className="absolute bottom-2 right-2 font-script text-[#4A3B32]/40 text-sm">
                    {galleryPage.captionPrefix} {i + 1}
                  </div>
                </motion.div>
              ))}
            </Masonry>
          </ResponsiveMasonry>
       </div>
    </div>
  );
};
