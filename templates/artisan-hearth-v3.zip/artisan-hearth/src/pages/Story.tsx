import React from 'react';
import { motion } from 'motion/react';
import { siteContent } from '../data/content';

export const Story = () => {
  const { storyPage, staticAssets } = siteContent;
  const { title, quote, rootedInTradition, theHearth, imageAlt } = storyPage;
  const imageSrc = staticAssets.images.story;

  return (
    <div className="min-h-screen py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-20">
          <h1 className="font-script text-6xl text-[#8C3A28] mb-6">{title}</h1>
          <p className="font-serif text-xl text-[#4A3B32]/80 max-w-2xl mx-auto leading-relaxed">
            {quote}
          </p>
        </div>

        {/* Section 1 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-24">
          <motion.div 
            initial={{ opacity: 0, x: -20 }} 
            animate={{ opacity: 1, x: 0 }}
            className="order-2 md:order-1"
          >
            <div className="prose prose-stone prose-lg text-[#4A3B32] font-serif">
              <h2 className="font-serif text-3xl text-[#4A5D23] mb-4">{rootedInTradition.heading}</h2>
              <p>
                {rootedInTradition.paragraph1}
              </p>
              <p>
                {rootedInTradition.paragraph2}
              </p>
            </div>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }} 
            animate={{ opacity: 1, scale: 1 }}
            className="order-1 md:order-2"
          >
            <div className="p-2 bg-white shadow-xl rotate-2">
              <img 
                src={imageSrc} 
                alt={imageAlt} 
                className="w-full h-[400px] object-cover"
              />
            </div>
          </motion.div>
        </div>

        {/* Section 2 */}
        <div className="bg-[#FCFAF2] p-12 shadow-lg rotate-[-1deg] mx-4 md:mx-0 border border-[#4A3B32]/5">
           <div className="text-center max-w-3xl mx-auto">
              <h3 className="font-script text-4xl text-[#8C3A28] mb-6">{theHearth.heading}</h3>
              <p className="font-serif text-lg text-[#4A3B32] leading-relaxed mb-8">
                 {theHearth.body}
              </p>
              <div className="font-serif text-sm uppercase tracking-widest text-[#4A5D23]">
                 {theHearth.signature}
              </div>
           </div>
        </div>

      </div>
    </div>
  );
};
