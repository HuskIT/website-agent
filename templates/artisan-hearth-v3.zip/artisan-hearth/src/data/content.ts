const siteText = {
  aboutTeaser: {
    heading: "Our Philosophy",
    body: "We believe that the best stories are shared over a meal. Our kitchen is an extension of our home, where we honor the hands that grew our food and the friends who gather to eat it.",
    cta: { label: "Read Our Story", link: "/story" },
    imageAlt: "Our Philosophy",
    caption: "Made with love",
  },
  branding: {
    name: "The Rustic Table",
    tagline: "Simple ingredients, timeless flavors, and a seat for everyone at our table.",
  },
  footer: {
    address: "128 Hearthstone Lane, Willow Creek, VT",
    copyrightTemplate: "The Rustic Table. All rights reserved.",
    hours: "Tue-Sun: 5pm - 10pm",
    visitUsHeading: "Visit Us",
    connectHeading: "Connect",
    established: "Est. 1998",
    makeReservationText: "Make a Reservation"
  },
  galleryPage: {
    title: "Moments",
    subtitle: "A visual diary of our days.",
    imageAltPrefix: "Gallery item",
    captionPrefix: "No.",
  },
  galleryTeaser: {
    heading: "Moments Shared",
    imageAltPrefix: "Gallery",
    cta: { label: "Visit Gallery", link: "/gallery" }
  },
  hero: {
    eyebrow: "Welcome Home",
    headline: "Simple Ingredients. Timeless Flavors.",
    subhead: "From our family farm to your table, we celebrate the honest taste of the seasons.",
    cta: { label: "Book a Table", link: "/reservations" },
    stamp: { fresh: "Fresh", daily: "Daily" },
    imageAlt: "Baker kneading dough in warm light"
  },
  menuHighlights: {
    heading: "From the Hearth",
    items: [
      {
        name: "Rosemary Sourdough",
        price: "$8",
        description: "Wild yeast, stone-ground flour, fresh rosemary, whipped sea salt butter."
      },
      {
        name: "Roasted Root Salad",
        price: "$16",
        description: "Heirloom beets, carrots, toasted walnuts, goat cheese, maple vinaigrette."
      },
      {
        name: "Slow-Braised Lamb",
        price: "$32",
        description: "Red wine reduction, polenta, charred greens, thyme."
      }
    ],
    cta: { label: "View Full Menu", link: "/menu" }
  },
  menuPage: {
    title: "Our Menu",
    subtitle: "Seasonal dishes inspired by the harvest.",
    categories: [
      {
        title: "Starters",
        items: [
          { name: "Rustic Sourdough", price: "$8", desc: "Whipped cultured butter, flaky sea salt" },
          { name: "Charred Carrots", price: "$14", desc: "Labneh, za'atar, honey, pistachio" },
          { name: "Heirloom Tomato Tart", price: "$16", desc: "Puff pastry, basil pesto, burrata" }
        ]
      },
      {
        title: "Mains",
        items: [
          { name: "Hand-Rolled Pappardelle", price: "$26", desc: "Wild mushroom ragu, parmesan, truffle oil" },
          { name: "Pan-Seared Trout", price: "$28", desc: "Warm potato salad, dill, lemon butter" },
          { name: "Farmhouse Roast Chicken", price: "$32", desc: "Root vegetables, thyme jus, crispy skin" },
          { name: "Grass-Fed Ribeye", price: "$45", desc: "Chimichurri, roasted garlic mash" }
        ]
      },
      {
        title: "Sweets",
        items: [
          { name: "Skillet Cookie", price: "$12", desc: "Dark chocolate, vanilla bean ice cream" },
          { name: "Lemon Olive Oil Cake", price: "$10", desc: "Mascarpone cream, seasonal berries" }
        ]
      }
    ],
  },
  navigation: [
    { label: "Home", path: "/" },
    { label: "Menu", path: "/menu" },
    { label: "Our Story", path: "/story" },
    { label: "Gallery", path: "/gallery" },
    { label: "Reservations", path: "/reservations", isCtaButton: true },
  ],
  reservations: {
    title: "Save a Seat",
    subtitle: "We'd love to host you. For parties larger than 6, please call us directly.",
    form: {
      nameLabel: "Name",
      emailLabel: "Email",
      dateLabel: "Date",
      guestsLabel: "Guests",
      notesLabel: "Notes",
      namePlaceholder: "Your name",
      emailPlaceholder: "email@example.com",
      notesPlaceholder: "Allergies, special occasions...",
    },
    guestOptions: ["2 Guests", "3 Guests", "4 Guests", "5 Guests", "6 Guests"],
    submitButton: "Request Booking",
    disclaimer: "*Reservations are held for 15 minutes.",
  },
  seo: {
    title: "The Rustic Table | Heirloom Recipes & Local Ingredients",
    description: "Experience the warmth of homemade cooking at The Rustic Table. Seasonal ingredients, family recipes, and a seat by the hearth.",
  },
  storyPage: {
    title: "Our Story",
    quote: "It started with a simple idea: good food takes time, and it tastes better when shared.",
    rootedInTradition: {
      heading: "Rooted in Tradition",
      paragraph1: "Founded in 1998, The Rustic Table was born from a desire to reconnect with the origins of our food. We believe that every ingredient tells a story—of the soil it grew in, the hands that harvested it, and the season it represents.",
      paragraph2: "Our recipes have been passed down through three generations, refined not by machines, but by memory and taste. We knead our bread by hand every morning before the sun rises, and we source our vegetables from farms within a 20-mile radius.",
    },
    theHearth: {
      heading: "The Hearth",
      body: "At the center of our restaurant lies the hearth—a wood-fired oven that never goes cold. It is the heart of our kitchen, imparting a distinct, smoky warmth to everything from our roasted vegetables to our slow-cooked meats. It reminds us that fire, like food, is a gathering place.",
      signature: "— The Family",
    },
    imageAlt: "Baker hands",
  }
};

const siteAssets = {
  socials: [
    { platform: "Instagram", url: "https://instagram.com/artisanhearth" },
    { platform: "Facebook", url: "https://facebook.com/artisanhearth" },
  ],
  staticAssets: {
    images: {
      aboutTeaser: "https://images.unsplash.com/photo-1715617029865-57cbbd44800f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3p5JTIwcnVzdGljJTIwcmVzdGF1cmFudCUyMGludGVyaW9yJTIwZ29sZGVuJTIwaG91ciUyMHdvb2RlbiUyMHRhYmxlc3xlbnwxfHx8fDE3NjQ0NzY3NzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      gallery: [
          "https://images.unsplash.com/photo-1760562796142-47e7799d6ba5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMG9yZ2FuaWMlMjB2ZWdldGFibGVzJTIwb24lMjB3b29kZW4lMjB0YWJsZSUyMGZhcm0lMjB0byUyMHRhYmxlfGVufDF8fHx8MTc2NDQyNDEzMHww&ixlib=rb-4.1.0&q=80&w=1080",
          "https://images.unsplash.com/photo-1649165484312-5ea739a10c05?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnRpc2FuJTIwYnJlYWQlMjBhbmQlMjBzb3VwJTIwcnVzdGljJTIwc2V0dGluZ3xlbnwxfHx8fDE3NjQ0NzY3NzJ8MA&ixlib=rb-4.1.0&q=80&w=1080",
          "https://images.unsplash.com/photo-1719865200855-01fea0667d85?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGZhbWlseSUyMGVhdGluZyUyMGRpbm5lciUyMHJ1c3RpYyUyMHJlc3RhdXJhbnQlMjBjYW5kaWR8ZW58MXx8fHwxNzY0NDc2NzcyfDA&ixlib=rb-4.1.0&q=80&w=1080",
          "https://images.unsplash.com/photo-1641394535269-dbea1fa94ff1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxydXN0aWMlMjBiYWtlcnklMjBoYW5kcyUyMGtuZWFkaW5nJTIwZG91Z2glMjB3YXJtJTIwbGlnaHR8ZW58MXx8fHwxNzY0NDc2NzcyfDA&ixlib=rb-4.1.0&q=80&w=1080",
          "https://images.unsplash.com/photo-1715617029865-57cbbd44800f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3p5JTIwcnVzdGljJTIwcmVzdGF1cmFudCUyMGludGVyaW9yJTIwZ29sZGVuJTIwaG91ciUyMHdvb2RlbiUyMHRhYmxlc3xlbnwxfHx8fDE3NjQ0NzY3NzJ8MA&ixlib=rb-4.1.0&q=80&w=1080",
          "https://images.unsplash.com/photo-1669743630567-a2d27ae3f0dc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVmJTIwcGxhdGluZyUyMGZvb2QlMjBydXN0aWMlMjBraXRjaGVufGVufDF8fHx8MTc2NDQ3NjkxNnww&ixlib=rb-4.1.0&q=80&w=1080",
          "https://images.unsplash.com/photo-1622289789785-b01ae28ad035?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxydXN0aWMlMjBmb29kJTIwcGxhdGluZyUyMHdvb2QlMjB0YWJsZXxlbnwxfHx8fDE3NjQ0NzY5MTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
          "https://images.unsplash.com/photo-1577050783516-87c79e0f9565?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aW5lJTIwZ2xhc3MlMjBydXN0aWMlMjB0YWJsZSUyMGV2ZW5pbmd8ZW58MXx8fHwxNzY0NDc2OTE2fDA&ixlib=rb-4.1.0&q=80&w=1080"
      ],
      hero: "https://images.unsplash.com/photo-1641394535269-dbea1fa94ff1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxydXN0aWMlMjBiYWtlcnklMjBoYW5kcyUyMGtuZWFkaW5nJTIwZG91Z2glMjB3YXJtJTIwbGlnaHR8ZW58MXx8fHwxNzY0NDc2NzcyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      story: "https://images.unsplash.com/photo-1641394535269-dbea1fa94ff1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxydXN0aWMlMjBiYWtlcnklMjBoYW5kcyUyMGtuZWFkaW5nJTIwZG91Z2glMjB3YXJtJTIwbGlnaHR8ZW58MXx8fHwxNzY0NDc2NzcyfDA&ixlib=rb-4.1.0&q=80&w=1080",
    }
  }
};

export const siteContent = { ...siteText, ...siteAssets };
